def optellen(nummer1, nummer2):
    return nummer1 + nummer2

def min(nummer1, nummer2):
    return nummer1 - nummer2

def keer(nummer1, nummer2):
    return nummer1 * nummer2

def delen(nummer1, nummer2):
    if nummer2 == 0:
        return "Error: kan niet delen door 0!"
    return nummer1 / nummer2