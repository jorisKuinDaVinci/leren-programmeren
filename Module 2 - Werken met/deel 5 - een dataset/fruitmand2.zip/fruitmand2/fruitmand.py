from random import shuffle

fruitmand = [{
    'name' : 'ananas',
    'weight' : 1590,
    'color' : 'yellow',
    'round' : False
},{
    'name' : 'banaan',
    'weight' : 120,
    'color' : 'yellow',
    'round' : False
},{
    'name' : 'mango',
    'weight' : 340,
    'color' : 'green',
    'round' : True
},{
    'name' : 'blauwebes',
    'weight' : 3,
    'color' : 'purple',
    'round' : True
},{
    'name' : 'pruim',
    'weight' : 110,
    'color' : 'purple',
    'round' : True
},{
    'name' : 'appel',
    'weight' : 195,
    'color' : 'green',
    'round' : True
},{
    'name' : 'citroen',
    'weight' : 100,
    'color' : 'yellow',
    'round' : True
},{
    'name' : 'peer',
    'weight' : 185,
    'color' : 'green',
    'round' : False
},{
    'name' : 'drakenfruit',
    'weight' : 500,
    'color' : 'pink',
    'round' : False
},{
    'name' : 'druif',
    'weight' : 5,
    'color' : 'green',
    'round' : True
},{
    'name' : 'braam',
    'weight' : 3,
    'color' : 'black',
    'round' : True
},{
    'name' : 'sinaasappel',
    'weight' : 130,
    'color' : 'orange',
    'round' : True
},{
    'name' : 'kiwi',
    'weight' : 75,
    'color' : 'brown',
    'round' : False
},{
    'name' : 'druif',
    'weight' : 5,
    'color' : 'purple',
    'round' : True
},{
    'name' : 'prachtframboos',
    'weight' : 3,
    'color' : 'pink',
    'round' : True
},{
    'name' : 'manderijn',
    'weight' : 125,
    'color' : 'orange',
    'round' : True
}]

shuffle(fruitmand)