import fruitmand
#Print alleen het totaal aantal stuks fruit in de fruitmand, probeer dit zo kort mogelijk te doen.
print(len(fruitmand.fruitmand))
