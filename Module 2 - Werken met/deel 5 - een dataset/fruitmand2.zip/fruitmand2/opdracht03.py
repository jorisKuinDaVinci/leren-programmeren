import fruitmand

# Print alleen de namen van al het fruit in de fruitmand met maximaal 3 regels code (minus lege regels en de import).
for fruit in fruitmand.fruitmand:
    print(fruit['name'])